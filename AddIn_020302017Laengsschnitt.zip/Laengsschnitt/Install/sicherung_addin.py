import arcpy
import pythonaddins
import os
import time

class LS(object):
    """Implementation for Laengsschnitt_addin.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        ### Get path to external toolbox
        toolbox = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Laengsschnitt.tbx')
        ### execute external script tool
        pythonaddins.GPToolDialog(toolbox, 'Gitter')
		# pythonaddins.GPToolDialog(r'E:\Studium\Masterarbeit\Profillinien\Blau\Laengsschnitt.tbx', 'Gitter')
		

class lineToPointXY(object):
    """Implementation for Laengsschnitt_addin.lineToPoint (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        ### Get path to external toolbox
        toolbox = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Laengsschnitt.tbx')
        ### execute external script tool
        pythonaddins.GPToolDialog(toolbox, 'lineToPoint')
		# pythonaddins.GPToolDialog(r'E:\Studium\Masterarbeit\Profillinien\Blau\Laengsschnitt.tbx', 'lineToPoint')

class openLayout(object):
    """Implementation for Laengsschnitt_addin.Layout (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
		fileDir = os.path.join(os.path.dirname(os.path.abspath(__file__)))
		fileLayout = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Laengsschnitt.mxd')
        mxd = arcpy.mapping.MapDocument(fileLayout)
		date = time.strftime('%H%M%S_%d%m%Y')
		newName = arcpy.CreateUniqueName("Laengsschnitt_"+date+".mxd")
		newMxd = os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), newName))
		mxd.saveACopy(newMxd)
		os.startfile(newMxd)