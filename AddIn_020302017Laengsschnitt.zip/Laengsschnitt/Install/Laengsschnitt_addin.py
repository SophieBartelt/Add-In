#-*- coding: utf-8 -*-


import arcpy
import pythonaddins
import os
import time
import arcpy.mapping

class LS(object):
    """Implementation for Laengsschnitt_addin.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
         ### Get path to external toolbox
        toolbox = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Laengsschnitt.tbx')
        ### execute external script tool
        pythonaddins.GPToolDialog(toolbox, 'Gitter')
		# pythonaddins.GPToolDialog(r'E:\Studium\Masterarbeit\Profillinien\Blau\Laengsschnitt.tbx', 'Gitter')

class lineToPointXY(object):
    """Implementation for Laengsschnitt_addin.lineToPoint (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        ### Get path to external toolbox
        toolbox = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Laengsschnitt.tbx')
        ### execute external script tool
        pythonaddins.GPToolDialog(toolbox, 'lineToPoint')
		# pythonaddins.GPToolDialog(r'E:\Studium\Masterarbeit\Profillinien\Blau\Laengsschnitt.tbx', 'lineToPoint')

class openLayout(object):
    """Implementation for Laengsschnitt_addin.Layout (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
		# Dateipfad zum MapDocument, in dem die Layoutelemente vorliegen
		fileLayout = os.path.join(os.path.dirname(os.path.abspath(__file__)), r'data\Laengsschnitt.mxd')
		layoutMxd = arcpy.mapping.MapDocument(fileLayout)
		# Der Dateipfad des aktuellen MapDocument
		currentMxd = arcpy.mapping.MapDocument('CURRENT')
		currentMxdPath = os.path.dirname(os.path.abspath(currentMxd.filePath))
		# Neuer Name fuer die Kopie des LayoutMapDocuments	 
		date = time.strftime('%H%M%S_%d%m%Y')
		newName = arcpy.CreateUniqueName("Laengsschnitt_"+date+".mxd")
		newMxd = os.path.join(currentMxdPath, newName)
		# Kopie mit neuem Namen speichern (im aktuellen Workspace)
		layoutMxd.saveACopy(newMxd)
		print newMxd
		# Kopie oeffnen
		os.startfile(newMxd)
		#os.close()