#-*- coding: utf-8 -*-


# Import arcpy module
import arcpy, arcpy.mapping
import exceptions, sys, traceback
import os, csv
from arcpy import env



# Current Workspace (only Folder available, no Database!)
workspace_01 = arcpy.GetParameterAsText(0)
arcpy.env.workspace = workspace_01

# Current MXD 
# getMxd = arcpy.GetParameterAsText(1)
mxd = arcpy.mapping.MapDocument("CURRENT") 


# Shape mit den Strecken und Höhenwerten (aus linepointmodell.py)
inputShape = arcpy.GetParameterAsText(1)

# Übergabewert Abfrage Maßstaebe
scaleHeight = float(arcpy.GetParameterAsText(2))
scaleLength = float(arcpy.GetParameterAsText(3))

# Standardlayer für Symbologie
styleLayer = arcpy.GetParameterAsText(4)

# Dateiname fuer Point Shape neue Tabelle mit Koodrinaten fuer das Gitter
outputPoints = arcpy.CreateUniqueName("schnitt_punkte.shp")
outputText = arcpy.CreateUniqueName("schnitt_text.shp")
outputProfil = arcpy.CreateUniqueName("schnitt_profillinien.shp")
outputProfil
out_path = workspace_01; outputPoints = os.path.basename(outputPoints); outputText = os.path.basename(outputText); outputProfil = os.path.basename(outputProfil)
geometry_type = "POINT"
template = inputShape
has_m = "ENABLED"; has_z = "DISABLED"
Expression_Type = "PYTHON_9.3"

# Spatial Refence festlegen
spatial_reference = arcpy.Describe(inputShape).spatialReference
# FeaturClass für das Gitter (Punkte) erstellen
arcpy.CreateFeatureclass_management(workspace_01, outputPoints, geometry_type, template, has_m, has_z, spatial_reference)
arcpy.CreateFeatureclass_management(workspace_01, outputText, geometry_type, template, has_m, has_z, spatial_reference)
arcpy.CreateFeatureclass_management(workspace_01, outputProfil, geometry_type, template, has_m, has_z, spatial_reference)



# CALCULATE EXPRESSIONS
	# nach der maximalen Höhe und Strecke suchen
myFieldX = "Strecke"  
minValueX = arcpy.SearchCursor(inputShape, "", "", "", myFieldX + " A").next().getValue(myFieldX) #Get 1st row in ascending cursor sort  
maxValueX = arcpy.SearchCursor(inputShape, "", "", "", myFieldX + " D").next().getValue(myFieldX) #Get 1st row in descending cursor sort 

myFieldY = "Z"  
minValueY = arcpy.SearchCursor(inputShape, "", "", "", myFieldY + " A").next().getValue(myFieldY) #Get 1st row in ascending cursor sort  
maxValueY = arcpy.SearchCursor(inputShape, "", "", "", myFieldY + " D").next().getValue(myFieldY) #Get 1st row in descending cursor sort   

# Maßstabsverhältnis
scaleRelation = scaleHeight/scaleLength
# Höhenwerte runden
arcpy.CalculateField_management(inputShape, "Z", "round(!Z!,3)", "PYTHON_9.3")


# Bereich vergrößern
maxValueX = (maxValueX+20)*scaleRelation
minValueX *= scaleRelation
maxValueY +=5;

cursor = arcpy.da.InsertCursor(outputPoints, ["SHAPE@"])
cursorText = arcpy.da.InsertCursor(outputText, ["SHAPE@"])
cursorProfil = arcpy.da.InsertCursor(outputProfil, ["SHAPE@"])
# Punkte hinzufügen
# mehrere Schleifen erstellen um einzelne Grafiken zu erstellen #
# XY Achsen
urspungx = minValueX-10; urspungy = minValueY-10;linienfeld=0
xy = ([urspungx,urspungy,linienfeld])
x1= ([maxValueX,urspungy,linienfeld])
y1= ([urspungx,maxValueY,linienfeld])
	  
cursor.insertRow([x1])
cursor.insertRow([xy])
cursor.insertRow([y1])


# Anzahl der Profilziele
valueList = [] # Array für Layernamen der Referenzprofile
fieldint = "Profilziel"
# Return list all permutations of field in input feature class or table  
def getValueList (table,field):

    valueSet = set() # set to hold values to test against to get list
    rows = arcpy.SearchCursor(table) # create search cursor
	
    # iterate through table and collect unique values
    for row in rows:
        value = row.getValue(field)
        # add value if not already added and not current year
        if value not in valueSet:
            valueList.append(value)

        # add value to valueset for checking against in next iteration
        valueSet.add(value)		

    # return value list
    # valueList.sort()
    return valueList

getValueList(inputShape,fieldint)
lenZiel = len(valueList)
zeileHarfeAx=urspungx-20;zeileHarfeEx=maxValueX

i = 0;
# Koordinaten für die Zeilen der Harfe
while i <= lenZiel:
	zeileY= urspungy-(i*5)
	linienfeld += 1
	zeileAxy = ([zeileHarfeAx,zeileY,linienfeld])
	zeileBxy = ([zeileHarfeEx,zeileY,linienfeld])
	cursor.insertRow([zeileAxy])
	cursor.insertRow([zeileBxy])
	if i > 0:
		zeileTextXy = ([zeileHarfeAx,zeileY,1])
		cursorText.insertRow([zeileTextXy])
	i+=1


# Spalten für die Harfe
linienfeld += 1
spalteAxy = ([zeileHarfeAx,urspungy,linienfeld])
spalteAxyE = ([zeileHarfeAx,zeileY,linienfeld])
cursor.insertRow([spalteAxy])
cursor.insertRow([spalteAxyE])

linienfeld += 1
spalteMxy = ([zeileHarfeEx,urspungy,linienfeld])
spalteMxyE = ([zeileHarfeEx,zeileY,linienfeld])
cursor.insertRow([spalteMxy])
cursor.insertRow([spalteMxyE])

linienfeld += 1
spalteBxy = ([urspungx,urspungy,linienfeld])
spalteBxyE = ([urspungx,zeileY,linienfeld])
cursor.insertRow([spalteBxy])
cursor.insertRow([spalteBxyE])

# Linien von der Sohle runter zur Harfe
valueListStrecke = [];valueListHoeheExt = []; valueListHoehe = []


# Höhen und Streckenwerte aus dem Shape in Listen speichern
def getValueListStrecke (table,field1,field2,field3):

    value1Set = set();value2Set = set() # set to hold values to test against to get list
    rows = arcpy.SearchCursor(table) # create search cursor
	
    # iterate through table and collect unique values
    for row in rows:
        value1 = row.getValue(field1);value2 = row.getValue(field2);value3 = row.getValue(field3);valueListHoeheExt.append(value3)
		# add value if not already added and not current year
        if value1 not in value1Set:
			valueListStrecke.append(value1)
			valueListHoehe.append(value2)

        # add value to valueset for checking against in next iteration
        value1Set.add(value1); value2Set.add(value2)		

    # return value list
    valueListStrecke.sort()
    return valueListStrecke,valueListHoehe, valueListHoeheExt


getValueListStrecke(inputShape,"Strecke","Z","Z")
lenStrecke = (len(valueListStrecke))-1
lenHoeheExt = (len(valueListHoeheExt))-1

e = 0;
linienfeld += 1000;

# Punkte für Linien von der Sohle bis Harfe
while e<=lenStrecke:
	linienfeld += 1; 
	tempValue = valueListStrecke[e]*scaleRelation
	spalteAYstrecke = ([tempValue,valueListHoehe[e],linienfeld])
	spalteBYstrecke = ([tempValue,zeileY,linienfeld])
	cursor.insertRow([spalteAYstrecke])	
	cursor.insertRow([spalteBYstrecke])
	e+=1


# Text-Punkte für Linien von der Sohle bis Harfe	
e = 0; i = 1
while i<=lenZiel:
	while e<=(lenHoeheExt/lenZiel):
		valueY = urspungy-(i*5)
		tempValue2 = valueListStrecke[e]*scaleRelation
		spalteAYhoehe = ([tempValue2,valueY,2])	
		cursorText.insertRow([spalteAYhoehe])
		e+=1
	e = 0
	i += 1
	
e = 0; a = 0;
while e<=lenZiel:
	i = 0
	while  i <= lenStrecke:
		valueX1 = (valueListStrecke[i])*scaleRelation
		if a < lenHoeheExt:
			valueY1 = valueListHoeheExt[a]
			XY_profil = ([valueX1,valueY1,e])	
			cursorProfil.insertRow([XY_profil])
		a += 1
		i += 1
	e += 1
	
	
	

# Kooridnaten hinzufügen
arcpy.AddXY_management(outputPoints); arcpy.AddXY_management(outputText);arcpy.AddXY_management(outputProfil)
# Linien Feature erstellen um Profilinien zu zeichnen
outputLineProfil="profillinien_linien.shp"
arcpy.PointsToLine_management(outputProfil,
                             outputLineProfil,
                              "POINT_M")
							  
# Linien Feature Class erstellen um Grafiken zu zeichnen
outputLine="schnitt_linien.shp"
arcpy.PointsToLine_management(outputPoints,
                             outputLine,
                              "POINT_M")

############### Textelemente in CSV schreiben, um sie später zu Verknüpfen
# Liste mit Referenznamen und List mit Höhen zusammenschreiben
mergedlist = valueList + valueListHoeheExt
csvfile = arcpy.CreateUniqueName("outputCSV.Csv")

with open(csvfile, "w") as output:
	writer = csv.writer(output, lineterminator='\n')   
	i = 0
	for val in mergedlist:
		writer.writerow([i, val])
		i +=1


	  
# Neues Shape als Layer zum ArcMAP-Document hinzufügen	
df = arcpy.mapping.ListDataFrames(mxd,"*")[0] 
			  
newLines = arcpy.mapping.Layer(outputLine)  
arcpy.mapping.AddLayer(df, newLines,"BOTTOM")

newPoints = arcpy.mapping.Layer(outputPoints)  
arcpy.mapping.AddLayer(df, newPoints,"BOTTOM")

newText = arcpy.mapping.Layer(outputText)  
arcpy.mapping.AddLayer(df, newText,"BOTTOM")

newProfil = arcpy.mapping.Layer(outputProfil)  
arcpy.mapping.AddLayer(df, newProfil,"BOTTOM")

newLineProfil = arcpy.mapping.Layer(outputLineProfil)  
arcpy.mapping.AddLayer(df, newLineProfil,"BOTTOM")

# Verknüpfen der CSV mit dem TEXT-Layer 
arcpy.AddJoin_management (newText, "FID", csvfile, "Field1")
outFeature = arcpy.CreateUniqueName("outFeature.shp")
arcpy.CopyFeatures_management(newText, outFeature)

newFeature = arcpy.mapping.Layer(outFeature)  
arcpy.mapping.AddLayer(df, newFeature,"BOTTOM")
arcpy.AddXY_management(newFeature)


### SYMBOLGIE vom vordifinierten Layer überschreiben
mapLayer = arcpy.mapping.Layer(styleLayer)  
arcpy.mapping.AddLayer(df, mapLayer,"BOTTOM")
inputLayer = newLines; symbologyLayer = mapLayer
arcpy.ApplySymbologyFromLayer_management(inputLayer,symbologyLayer)

####


df.elementPositionY = 0; df.elementPositionX = 0
df.scale = scaleHeight
df.panToExtent(newLines.getSelectedExtent())


# Graphik-Elemente des Layout

horzLine = arcpy.mapping.ListLayoutElements(mxd, "GRAPHIC_ELEMENT", "horzLine")[0]
vertLine = arcpy.mapping.ListLayoutElements(mxd, "GRAPHIC_ELEMENT", "vertLine")[0]
textField = arcpy.mapping.ListLayoutElements(mxd, "TEXT_ELEMENT", "Text")[0]	
title = arcpy.mapping.ListLayoutElements(mxd, "TEXT_ELEMENT", "Titel")[0]

#Titel
title.text = 'Hydrologischer Laengsschnitt'
title.fontSize = 18
title.elementPositionX = df.elementPositionX + (df.elementWidth*0.5) - (title.elementWidth*0.5)
title.elementPositionY = df.elementPositionY + (df.elementHeight*0.9) - (title.elementHeight*0.5)

### Plankopf
dfLowerRight = df.elementWidth
vertLine.elementPositionX = dfLowerRight-10 
vertLine.elementPositionY = 10; vertLine.elementHeight =  100	
horzLine.elementPositionX = dfLowerRight-110 
horzLine.elementPositionY = 10; horzLine.elementWidth =  100

	# Das graphikelement clonen um neue Linien herzustellen
temp_horz = horzLine.clone("_clone");temp_vert = vertLine.clone("_clone")
temp_vert.elementPositionX = dfLowerRight-110  
temp_horz.elementPositionY = 110; 
	
	# Plankopftext
textField.text = 'Plankopf'	; textField.fontSize = 12;
textField.elementPositionX = temp_vert.elementPositionX + 5
textField.elementPositionY = temp_horz.elementPositionY - 10
#temp_text = textField.clone("_clone"); 		
		
# Refresh 
#arcpy.Delete_management(mapLayer)
arcpy.RefreshActiveView()
arcpy.RefreshTOC()

arcpy.mapping.ExportToPDF(mxd, "Laengsschnitt.pdf", df, df_export_width=1600, df_export_height=1200, resolution	= 600)
del mxd, df							  
